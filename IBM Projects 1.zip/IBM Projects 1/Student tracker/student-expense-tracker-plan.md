# Student Expense Tracker — Implementation Plan

## Overview

Build a small, learning-oriented Student Expense Tracker web application using:
- **Python** with object-oriented design
- **Streamlit** for the web UI
- **JSON** for data persistence
- **pytest** for unit testing

Users can add, view, filter, and delete expenses, and view category-wise spending summaries.
No authentication, payment systems, or external APIs are in scope.

---

## Project Structure

```
student-expense-tracker/
├── app.py                  # Streamlit UI entry point
├── models/
│   └── expense.py          # Expense dataclass/model
├── services/
│   └── expense_service.py  # Business logic
├── repository/
│   └── expense_repository.py  # JSON read/write
├── utils/
│   └── validator.py        # Input validation rules
│   └── exceptions.py       # Custom exceptions
├── tests/
│   ├── test_expense_service.py
│   ├── test_validator.py
│   └── test_expense_repository.py
├── data/
│   └── expenses.json       # Persisted expense records
└── requirements.txt
```

---

## Sub-Task 1 — Define the Expense Model

**Status:** [ ] pending

### Intent
Define the core data structure that represents a single expense record.
All other components depend on this model, so it must be defined first.

### Expected Outcomes
- An `Expense` class exists with all required fields
- It can be serialized to and deserialized from a dict (for JSON I/O)
- It carries a unique ID so individual records can be deleted

### Todo List
1. Create `models/expense.py`
2. Define `Expense` with fields:
   - `id` (str — UUID)
   - `amount` (float)
   - `category` (str — from a fixed list)
   - `date` (str — ISO format YYYY-MM-DD)
   - `description` (str)
3. Add `to_dict()` method for JSON serialization
4. Add `from_dict()` class method for deserialization
5. Define the allowed categories as a module-level constant:
   `CATEGORIES = ["Food", "Transport", "Accommodation", "Books", "Entertainment", "Other"]`

### Relevant Context
- No external libraries needed; use Python `dataclasses` or plain class
- `uuid.uuid4()` for ID generation
- Date stored as string to keep JSON simple

---

## Sub-Task 2 — Custom Exceptions

**Status:** [ ] pending

### Intent
Define application-specific exceptions so errors can be caught and displayed
meaningfully in the UI without leaking raw Python errors.

### Expected Outcomes
- A `ValidationError` exception class exists for invalid input
- A `ExpenseNotFoundError` exception class exists for delete-by-ID failures

### Todo List
1. Create `utils/exceptions.py`
2. Define `ValidationError(Exception)`
3. Define `ExpenseNotFoundError(Exception)`

---

## Sub-Task 3 — Input Validator

**Status:** [ ] pending

### Intent
Centralise all input validation rules in one place.
The service layer calls the validator before persisting data.

### Expected Outcomes
- `Validator` class with static/class methods for each field
- Raises `ValidationError` with a descriptive message on failure
- Fully unit-testable in isolation

### Todo List
1. Create `utils/validator.py`
2. Implement `validate_amount(amount)`:
   - Must be a positive number
   - Must not exceed 1,000,000
3. Implement `validate_date(date_str)`:
   - Must match YYYY-MM-DD format
   - Must not be a future date
4. Implement `validate_category(category)`:
   - Must be one of the allowed CATEGORIES
5. Implement `validate_description(description)`:
   - Must not be empty
   - Max 200 characters
6. Implement `validate_expense(expense)` that calls all of the above

### Validation Rules Summary
| Field | Rule |
|---|---|
| amount | > 0, ≤ 1,000,000, numeric |
| date | YYYY-MM-DD, not in future |
| category | must be in CATEGORIES list |
| description | non-empty, ≤ 200 chars |

---

## Sub-Task 4 — Expense Repository

**Status:** [ ] pending

### Intent
Encapsulate all JSON file I/O in one class.
The service layer never reads or writes files directly.

### Expected Outcomes
- `ExpenseRepository` loads and saves `data/expenses.json`
- Creates the file if it doesn't exist
- Exposes clean CRUD-level methods

### Todo List
1. Create `repository/expense_repository.py`
2. Implement `__init__` — set file path, ensure `data/` directory and file exist
3. Implement `load_all() -> list[Expense]` — reads JSON, deserializes to Expense objects
4. Implement `save_all(expenses: list[Expense])` — serializes and writes all records
5. Implement `add(expense: Expense)` — load, append, save
6. Implement `delete(expense_id: str)` — load, remove by ID, save; raise `ExpenseNotFoundError` if not found
7. Implement `get_all() -> list[Expense]` — returns all loaded records

### Data Format (expenses.json)
```json
[
  {
    "id": "uuid-string",
    "amount": 250.0,
    "category": "Food",
    "date": "2024-06-01",
    "description": "Lunch at canteen"
  }
]
```

---

## Sub-Task 5 — Expense Service

**Status:** [ ] pending

### Intent
Implement all business logic. This is the layer between the UI and the repository.
The UI calls only service methods — never the repository or validator directly.

### Expected Outcomes
- `ExpenseService` coordinates validation, ID generation, and persistence
- All filtering and aggregation logic lives here, not in the UI
- Each method has a single, clear responsibility

### Todo List
1. Create `services/expense_service.py`
2. `__init__` — compose with `ExpenseRepository` and `Validator`
3. `add_expense(amount, category, date, description) -> Expense`:
   - Build Expense object with new UUID
   - Call validator
   - Call repository.add()
   - Return saved Expense
4. `get_all_expenses() -> list[Expense]`
5. `delete_expense(expense_id: str)`
6. `filter_by_category(category: str) -> list[Expense]`
7. `filter_by_date_range(start: str, end: str) -> list[Expense]`
8. `calculate_total(expenses: list[Expense]) -> float`
9. `category_summary(expenses: list[Expense]) -> dict[str, float]`:
   - Returns `{category: total_amount}` for the given list

---

## Sub-Task 6 — Streamlit UI

**Status:** [ ] pending

### Intent
Build the web interface using Streamlit. All UI logic lives in `app.py`.
The UI is a thin layer — it collects input, calls the service, and renders results.

### Expected Outcomes
- Single-page Streamlit app with sidebar navigation
- All user-facing validation errors displayed as `st.error()` messages
- No business logic in `app.py`

### Streamlit UI Components

#### Sidebar — Navigation
- Radio buttons: `Add Expense | View Expenses | Summary`

#### Page: Add Expense
| Component | Streamlit Widget |
|---|---|
| Amount | `st.number_input` |
| Category | `st.selectbox` (CATEGORIES list) |
| Date | `st.date_input` |
| Description | `st.text_area` |
| Submit | `st.button("Add Expense")` |
| Success/Error | `st.success()` / `st.error()` |

#### Page: View Expenses
| Component | Streamlit Widget |
|---|---|
| Filter by Category | `st.selectbox` (+ "All" option) |
| Filter by Date Range | `st.date_input` (range) |
| Expense Table | `st.dataframe` |
| Delete Button | `st.button` per row (via `st.expander` or index) |
| Total | `st.metric("Total Spent", value)` |

#### Page: Summary
| Component | Streamlit Widget |
|---|---|
| Category-wise totals | `st.bar_chart` or `st.dataframe` |
| Overall total | `st.metric` |

### Todo List
1. Create `app.py`
2. Instantiate `ExpenseService` (cached with `st.cache_resource`)
3. Build sidebar navigation
4. Implement Add Expense form with validation error display
5. Implement View Expenses with filter controls and delete action
6. Implement Summary page with category totals and chart

---

## Sub-Task 7 — Unit Tests

**Status:** [ ] pending

### Intent
Write pytest tests for the three testable layers: validator, service, and repository.
The UI is not unit tested (Streamlit UI testing is out of scope for this demo).

### Expected Outcomes
- All happy-path cases covered
- Key validation failure cases covered
- Tests are isolated (no shared state between tests)

### Todo List
1. Create `tests/test_validator.py`:
   - Valid amount passes
   - Zero/negative amount raises `ValidationError`
   - Future date raises `ValidationError`
   - Invalid category raises `ValidationError`
   - Empty description raises `ValidationError`

2. Create `tests/test_expense_service.py`:
   - `add_expense` returns an Expense with a UUID
   - `filter_by_category` returns only matching records
   - `filter_by_date_range` returns correct records
   - `calculate_total` sums correctly
   - `category_summary` groups correctly
   - `delete_expense` with unknown ID raises `ExpenseNotFoundError`

3. Create `tests/test_expense_repository.py`:
   - Uses `tmp_path` pytest fixture for a temp JSON file
   - `add` then `get_all` returns the added record
   - `delete` removes the correct record
   - `delete` with bad ID raises `ExpenseNotFoundError`

---

## Sub-Task 8 — Project Bootstrap

**Status:** [ ] pending

### Intent
Set up the project skeleton so all files and dependencies are in place
before any implementation begins.

### Expected Outcomes
- `requirements.txt` lists all dependencies
- `data/expenses.json` initialised as empty array `[]`
- All `__init__.py` files in place

### Todo List
1. Create `requirements.txt` with: `streamlit`, `pytest`
2. Create `data/expenses.json` with content `[]`
3. Create empty `__init__.py` in `models/`, `services/`, `repository/`, `utils/`, `tests/`

---

## Data Flow

```
User Input (Streamlit)
    ↓
app.py collects raw values
    ↓
ExpenseService.add_expense(...)
    ↓
Validator.validate_expense(expense)  ← raises ValidationError if invalid
    ↓
ExpenseRepository.add(expense)
    ↓
expenses.json (persisted)
    ↓
app.py re-reads via ExpenseService.get_all_expenses()
    ↓
st.dataframe renders the updated list
```

---

## Implementation Sequence

1. Sub-Task 8 — Project Bootstrap
2. Sub-Task 1 — Expense Model
3. Sub-Task 2 — Custom Exceptions
4. Sub-Task 3 — Validator
5. Sub-Task 4 — Repository
6. Sub-Task 5 — Service
7. Sub-Task 7 — Unit Tests
8. Sub-Task 6 — Streamlit UI
