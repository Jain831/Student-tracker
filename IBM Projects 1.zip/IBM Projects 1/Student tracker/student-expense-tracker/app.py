"""Student Expense Tracker — Streamlit UI entry point."""

from __future__ import annotations

import streamlit as st
from datetime import date

from models.expense import CATEGORIES
from services.expense_service import ExpenseService
from utils.exceptions import ExpenseNotFoundError, ValidationError


# ---------------------------------------------------------------------------
# Service — cached so it survives re-runs without re-reading the file
# ---------------------------------------------------------------------------

@st.cache_resource
def get_service() -> ExpenseService:
    return ExpenseService()


service = get_service()

# ---------------------------------------------------------------------------
# Page configuration
# ---------------------------------------------------------------------------

st.set_page_config(page_title="Student Expense Tracker", page_icon="💰", layout="centered")
st.title("💰 Student Expense Tracker")

# ---------------------------------------------------------------------------
# Sidebar navigation
# ---------------------------------------------------------------------------

page = st.sidebar.radio(
    "Navigation",
    ["➕ Add Expense", "📋 View Expenses", "📊 Summary"],
)

# ---------------------------------------------------------------------------
# Page: Add Expense
# ---------------------------------------------------------------------------

if page == "➕ Add Expense":
    st.header("Add New Expense")

    with st.form("add_expense_form", clear_on_submit=True):
        amount = st.number_input("Amount (₹)", min_value=0.0, step=0.01, format="%.2f")
        category = st.selectbox("Category", CATEGORIES)
        expense_date = st.date_input("Date", value=date.today(), max_value=date.today())
        description = st.text_area("Description", max_chars=200, placeholder="e.g. Lunch at canteen")
        submitted = st.form_submit_button("Add Expense")

    if submitted:
        try:
            saved = service.add_expense(
                amount=amount,
                category=category,
                date=expense_date.isoformat(),
                description=description,
            )
            st.success(f"✅ Expense added! (ID: {saved.id[:8]}…)")
        except ValidationError as exc:
            st.error(f"❌ Validation error: {exc}")

# ---------------------------------------------------------------------------
# Page: View Expenses
# ---------------------------------------------------------------------------

elif page == "📋 View Expenses":
    st.header("View Expenses")

    all_expenses = service.get_all_expenses()

    # --- Filters ---
    col1, col2 = st.columns(2)
    with col1:
        cat_filter = st.selectbox("Filter by Category", ["All"] + CATEGORIES)
    with col2:
        date_range = st.date_input(
            "Filter by Date Range",
            value=(date(2020, 1, 1), date.today()),
        )

    # Apply filters
    expenses = all_expenses
    if cat_filter != "All":
        expenses = service.filter_by_category(cat_filter)

    if isinstance(date_range, (list, tuple)) and len(date_range) == 2:
        start_str = date_range[0].isoformat()
        end_str = date_range[1].isoformat()
        expenses = [e for e in expenses if start_str <= e.date <= end_str]

    # --- Total ---
    total = service.calculate_total(expenses)
    st.metric("Total Spent", f"₹ {total:,.2f}")

    if not expenses:
        st.info("No expenses found for the selected filters.")
    else:
        # --- Table ---
        st.subheader("Expense Records")
        for expense in sorted(expenses, key=lambda e: e.date, reverse=True):
            with st.expander(
                f"{expense.date} | {expense.category} | ₹ {expense.amount:,.2f} — {expense.description[:50]}"
            ):
                st.write(f"**ID:** {expense.id}")
                st.write(f"**Amount:** ₹ {expense.amount:,.2f}")
                st.write(f"**Category:** {expense.category}")
                st.write(f"**Date:** {expense.date}")
                st.write(f"**Description:** {expense.description}")
                if st.button("🗑️ Delete this expense", key=f"del_{expense.id}"):
                    try:
                        service.delete_expense(expense.id)
                        st.success("Expense deleted.")
                        st.rerun()
                    except ExpenseNotFoundError as exc:
                        st.error(str(exc))

# ---------------------------------------------------------------------------
# Page: Summary
# ---------------------------------------------------------------------------

elif page == "📊 Summary":
    st.header("Spending Summary")

    all_expenses = service.get_all_expenses()
    total = service.calculate_total(all_expenses)
    st.metric("Overall Total Spent", f"₹ {total:,.2f}")
    st.metric("Total Transactions", len(all_expenses))

    if not all_expenses:
        st.info("No expenses recorded yet.")
    else:
        summary = service.category_summary(all_expenses)

        st.subheader("Category-wise Breakdown")
        # Bar chart
        st.bar_chart(summary)

        # Table
        st.subheader("Detailed Totals")
        rows = [
            {"Category": cat, "Total (₹)": f"{amt:,.2f}"}
            for cat, amt in sorted(summary.items(), key=lambda x: x[1], reverse=True)
        ]
        st.dataframe(rows, use_container_width=True)
