"""Input validation rules for expense fields."""

from __future__ import annotations

from datetime import date

from models.expense import CATEGORIES, Expense
from utils.exceptions import ValidationError


class Validator:
    """Validates expense field values, raising ValidationError on failure."""

    @staticmethod
    def validate_amount(amount: float) -> None:
        """Amount must be a positive number not exceeding 1,000,000."""
        if not isinstance(amount, (int, float)):
            raise ValidationError("Amount must be a number.")
        if amount <= 0:
            raise ValidationError("Amount must be greater than zero.")
        if amount > 1_000_000:
            raise ValidationError("Amount must not exceed 1,000,000.")

    @staticmethod
    def validate_date(date_str: str) -> None:
        """Date must be a valid YYYY-MM-DD string and not in the future."""
        try:
            parsed = date.fromisoformat(date_str)
        except (ValueError, TypeError):
            raise ValidationError("Date must be in YYYY-MM-DD format.")
        if parsed > date.today():
            raise ValidationError("Date must not be in the future.")

    @staticmethod
    def validate_category(category: str) -> None:
        """Category must be one of the allowed CATEGORIES."""
        if category not in CATEGORIES:
            raise ValidationError(
                f"Category must be one of: {', '.join(CATEGORIES)}."
            )

    @staticmethod
    def validate_description(description: str) -> None:
        """Description must be non-empty and at most 200 characters."""
        if not description or not description.strip():
            raise ValidationError("Description must not be empty.")
        if len(description) > 200:
            raise ValidationError("Description must not exceed 200 characters.")

    @classmethod
    def validate_expense(cls, expense: Expense) -> None:
        """Run all field-level validations for an Expense instance."""
        cls.validate_amount(expense.amount)
        cls.validate_date(expense.date)
        cls.validate_category(expense.category)
        cls.validate_description(expense.description)
