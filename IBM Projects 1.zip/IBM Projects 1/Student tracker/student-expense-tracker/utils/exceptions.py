"""Application-specific exceptions."""


class ValidationError(Exception):
    """Raised when user-supplied input fails validation rules."""


class ExpenseNotFoundError(Exception):
    """Raised when an expense with the given ID cannot be found."""
