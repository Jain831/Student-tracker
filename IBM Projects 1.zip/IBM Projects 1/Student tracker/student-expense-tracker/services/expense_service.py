"""Business logic layer for the Student Expense Tracker."""

from __future__ import annotations

from models.expense import Expense
from repository.expense_repository import ExpenseRepository
from utils.validator import Validator


class ExpenseService:
    """
    Coordinates validation, ID generation, persistence, filtering,
    and aggregation. The UI should call only this layer.
    """

    def __init__(self, repository: ExpenseRepository | None = None) -> None:
        self._repo = repository or ExpenseRepository()
        self._validator = Validator()

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def add_expense(
        self,
        amount: float,
        category: str,
        date: str,
        description: str,
    ) -> Expense:
        """Validate and persist a new expense. Returns the saved Expense."""
        expense = Expense(
            amount=amount,
            category=category,
            date=date,
            description=description,
        )
        Validator.validate_expense(expense)
        self._repo.add(expense)
        return expense

    def delete_expense(self, expense_id: str) -> None:
        """Delete an expense by ID. Propagates ExpenseNotFoundError."""
        self._repo.delete(expense_id)

    # ------------------------------------------------------------------
    # Read / query operations
    # ------------------------------------------------------------------

    def get_all_expenses(self) -> list[Expense]:
        """Return all stored expense records."""
        return self._repo.get_all()

    def filter_by_category(self, category: str) -> list[Expense]:
        """Return expenses matching the given category."""
        return [e for e in self.get_all_expenses() if e.category == category]

    def filter_by_date_range(self, start: str, end: str) -> list[Expense]:
        """Return expenses whose date falls within [start, end] inclusive."""
        return [
            e for e in self.get_all_expenses()
            if start <= e.date <= end
        ]

    # ------------------------------------------------------------------
    # Aggregation operations
    # ------------------------------------------------------------------

    def calculate_total(self, expenses: list[Expense]) -> float:
        """Return the sum of amounts for the given expense list."""
        return round(sum(e.amount for e in expenses), 2)

    def category_summary(self, expenses: list[Expense]) -> dict[str, float]:
        """Return a mapping of category → total amount for the given list."""
        summary: dict[str, float] = {}
        for expense in expenses:
            summary[expense.category] = round(
                summary.get(expense.category, 0.0) + expense.amount, 2
            )
        return summary
