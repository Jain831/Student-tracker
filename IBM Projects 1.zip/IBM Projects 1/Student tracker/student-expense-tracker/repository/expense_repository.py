"""JSON-backed persistence layer for Expense records."""

from __future__ import annotations

import json
import os
from pathlib import Path

from models.expense import Expense
from utils.exceptions import ExpenseNotFoundError

_DEFAULT_PATH = Path(__file__).parent.parent / "data" / "expenses.json"


class ExpenseRepository:
    """Reads and writes expense records to a JSON file."""

    def __init__(self, file_path: Path | None = None) -> None:
        self._path: Path = Path(file_path) if file_path else _DEFAULT_PATH
        self._path.parent.mkdir(parents=True, exist_ok=True)
        if not self._path.exists():
            self._path.write_text("[]", encoding="utf-8")

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _load_raw(self) -> list[dict]:
        text = self._path.read_text(encoding="utf-8").strip()
        if not text:
            return []
        return json.loads(text)

    def _save_raw(self, records: list[dict]) -> None:
        self._path.write_text(
            json.dumps(records, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load_all(self) -> list[Expense]:
        """Load and deserialize all expense records from disk."""
        return [Expense.from_dict(r) for r in self._load_raw()]

    def save_all(self, expenses: list[Expense]) -> None:
        """Serialize and persist a full list of expense records."""
        self._save_raw([e.to_dict() for e in expenses])

    def get_all(self) -> list[Expense]:
        """Return all expense records (alias for load_all)."""
        return self.load_all()

    def add(self, expense: Expense) -> None:
        """Append a new expense record and persist."""
        records = self._load_raw()
        records.append(expense.to_dict())
        self._save_raw(records)

    def delete(self, expense_id: str) -> None:
        """Remove an expense by ID. Raises ExpenseNotFoundError if missing."""
        records = self._load_raw()
        updated = [r for r in records if r["id"] != expense_id]
        if len(updated) == len(records):
            raise ExpenseNotFoundError(
                f"No expense found with id '{expense_id}'."
            )
        self._save_raw(updated)
