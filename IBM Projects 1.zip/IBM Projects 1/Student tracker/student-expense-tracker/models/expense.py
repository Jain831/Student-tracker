"""Expense model and allowed categories."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any

CATEGORIES: list[str] = [
    "Food",
    "Transport",
    "Accommodation",
    "Books",
    "Entertainment",
    "Other",
]


@dataclass
class Expense:
    """Represents a single student expense record."""

    amount: float
    category: str
    date: str          # ISO format: YYYY-MM-DD
    description: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dict suitable for JSON storage."""
        return {
            "id": self.id,
            "amount": self.amount,
            "category": self.category,
            "date": self.date,
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Expense":
        """Deserialize from a plain dict (e.g. loaded from JSON)."""
        return cls(
            id=data["id"],
            amount=float(data["amount"]),
            category=data["category"],
            date=data["date"],
            description=data["description"],
        )
