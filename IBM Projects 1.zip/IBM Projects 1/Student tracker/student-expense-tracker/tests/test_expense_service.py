"""Unit tests for the ExpenseService class."""

import pytest
from pathlib import Path
from datetime import date

from models.expense import Expense
from repository.expense_repository import ExpenseRepository
from services.expense_service import ExpenseService
from utils.exceptions import ExpenseNotFoundError, ValidationError


@pytest.fixture()
def service(tmp_path: Path) -> ExpenseService:
    """Return a fresh service backed by an isolated temp repository."""
    repo = ExpenseRepository(file_path=tmp_path / "expenses.json")
    return ExpenseService(repository=repo)


def _today() -> str:
    return date.today().isoformat()


class TestAddExpense:
    def test_returns_expense_with_uuid(self, service):
        expense = service.add_expense(50.0, "Food", _today(), "Lunch")
        assert isinstance(expense, Expense)
        assert expense.id  # non-empty UUID string

    def test_saved_to_repository(self, service):
        service.add_expense(50.0, "Books", _today(), "Textbook")
        all_expenses = service.get_all_expenses()
        assert len(all_expenses) == 1

    def test_invalid_amount_raises(self, service):
        with pytest.raises(ValidationError):
            service.add_expense(-10.0, "Food", _today(), "Bad amount")

    def test_invalid_date_raises(self, service):
        with pytest.raises(ValidationError):
            service.add_expense(50.0, "Food", "not-a-date", "Bad date")


class TestFilterByCategory:
    def test_returns_only_matching_records(self, service):
        service.add_expense(50.0, "Food", _today(), "Lunch")
        service.add_expense(20.0, "Transport", _today(), "Bus")
        result = service.filter_by_category("Food")
        assert len(result) == 1
        assert result[0].category == "Food"

    def test_returns_empty_for_no_matches(self, service):
        service.add_expense(50.0, "Food", _today(), "Lunch")
        result = service.filter_by_category("Books")
        assert result == []


class TestFilterByDateRange:
    def test_returns_records_within_range(self, service):
        service.add_expense(100.0, "Food", "2024-03-01", "In range")
        service.add_expense(200.0, "Food", "2024-05-15", "Out of range")
        result = service.filter_by_date_range("2024-01-01", "2024-04-01")
        assert len(result) == 1
        assert result[0].description == "In range"

    def test_inclusive_boundaries(self, service):
        service.add_expense(100.0, "Food", "2024-03-01", "Start")
        service.add_expense(100.0, "Food", "2024-03-31", "End")
        result = service.filter_by_date_range("2024-03-01", "2024-03-31")
        assert len(result) == 2


class TestCalculateTotal:
    def test_sums_correctly(self, service):
        expenses = [
            Expense(amount=100.0, category="Food", date=_today(), description="A"),
            Expense(amount=50.5, category="Books", date=_today(), description="B"),
        ]
        assert service.calculate_total(expenses) == 150.5

    def test_empty_list_returns_zero(self, service):
        assert service.calculate_total([]) == 0.0


class TestCategorySummary:
    def test_groups_by_category(self, service):
        expenses = [
            Expense(amount=100.0, category="Food", date=_today(), description="A"),
            Expense(amount=50.0, category="Food", date=_today(), description="B"),
            Expense(amount=30.0, category="Books", date=_today(), description="C"),
        ]
        summary = service.category_summary(expenses)
        assert summary["Food"] == 150.0
        assert summary["Books"] == 30.0

    def test_empty_list_returns_empty_dict(self, service):
        assert service.category_summary([]) == {}


class TestDeleteExpense:
    def test_delete_removes_expense(self, service):
        expense = service.add_expense(100.0, "Food", _today(), "Lunch")
        service.delete_expense(expense.id)
        assert service.get_all_expenses() == []

    def test_delete_unknown_id_raises(self, service):
        with pytest.raises(ExpenseNotFoundError):
            service.delete_expense("does-not-exist")
