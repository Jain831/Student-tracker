"""Unit tests for the Validator class."""

import pytest
from datetime import date, timedelta

from utils.validator import Validator
from utils.exceptions import ValidationError


class TestValidateAmount:
    def test_valid_amount_passes(self):
        Validator.validate_amount(100.0)  # should not raise

    def test_zero_raises(self):
        with pytest.raises(ValidationError, match="greater than zero"):
            Validator.validate_amount(0)

    def test_negative_raises(self):
        with pytest.raises(ValidationError, match="greater than zero"):
            Validator.validate_amount(-50)

    def test_exceeds_limit_raises(self):
        with pytest.raises(ValidationError, match="1,000,000"):
            Validator.validate_amount(1_000_001)

    def test_non_numeric_raises(self):
        with pytest.raises(ValidationError, match="number"):
            Validator.validate_amount("abc")  # type: ignore[arg-type]


class TestValidateDate:
    def test_valid_today_passes(self):
        Validator.validate_date(date.today().isoformat())

    def test_valid_past_date_passes(self):
        Validator.validate_date("2023-01-15")

    def test_future_date_raises(self):
        future = (date.today() + timedelta(days=1)).isoformat()
        with pytest.raises(ValidationError, match="future"):
            Validator.validate_date(future)

    def test_invalid_format_raises(self):
        with pytest.raises(ValidationError, match="YYYY-MM-DD"):
            Validator.validate_date("15-01-2023")

    def test_none_raises(self):
        with pytest.raises(ValidationError, match="YYYY-MM-DD"):
            Validator.validate_date(None)  # type: ignore[arg-type]


class TestValidateCategory:
    def test_valid_category_passes(self):
        Validator.validate_category("Food")

    def test_invalid_category_raises(self):
        with pytest.raises(ValidationError, match="Category must be one of"):
            Validator.validate_category("Groceries")


class TestValidateDescription:
    def test_valid_description_passes(self):
        Validator.validate_description("Lunch at canteen")

    def test_empty_raises(self):
        with pytest.raises(ValidationError, match="empty"):
            Validator.validate_description("")

    def test_whitespace_only_raises(self):
        with pytest.raises(ValidationError, match="empty"):
            Validator.validate_description("   ")

    def test_too_long_raises(self):
        with pytest.raises(ValidationError, match="200 characters"):
            Validator.validate_description("x" * 201)
