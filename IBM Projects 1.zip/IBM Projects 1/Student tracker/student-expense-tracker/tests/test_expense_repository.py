"""Unit tests for the ExpenseRepository class."""

import json
import pytest
from pathlib import Path

from models.expense import Expense
from repository.expense_repository import ExpenseRepository
from utils.exceptions import ExpenseNotFoundError


@pytest.fixture()
def repo(tmp_path: Path) -> ExpenseRepository:
    """Return a fresh repository backed by a temp file."""
    return ExpenseRepository(file_path=tmp_path / "test_expenses.json")


def _make_expense(**kwargs) -> Expense:
    defaults = dict(amount=100.0, category="Food", date="2024-01-10", description="Test")
    defaults.update(kwargs)
    return Expense(**defaults)


class TestRepositoryAdd:
    def test_add_then_get_all_returns_record(self, repo):
        expense = _make_expense()
        repo.add(expense)
        result = repo.get_all()
        assert len(result) == 1
        assert result[0].id == expense.id
        assert result[0].amount == 100.0

    def test_add_multiple_records(self, repo):
        repo.add(_make_expense())
        repo.add(_make_expense(amount=200.0))
        assert len(repo.get_all()) == 2


class TestRepositoryDelete:
    def test_delete_removes_correct_record(self, repo):
        e1 = _make_expense(description="First")
        e2 = _make_expense(description="Second")
        repo.add(e1)
        repo.add(e2)
        repo.delete(e1.id)
        remaining = repo.get_all()
        assert len(remaining) == 1
        assert remaining[0].id == e2.id

    def test_delete_unknown_id_raises(self, repo):
        with pytest.raises(ExpenseNotFoundError):
            repo.delete("non-existent-id")


class TestRepositoryPersistence:
    def test_data_survives_reload(self, tmp_path):
        path = tmp_path / "expenses.json"
        repo1 = ExpenseRepository(file_path=path)
        expense = _make_expense(description="Persist me")
        repo1.add(expense)

        # Create a second repo pointing to the same file
        repo2 = ExpenseRepository(file_path=path)
        result = repo2.get_all()
        assert len(result) == 1
        assert result[0].description == "Persist me"
